﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebLogin.Models;

namespace WebLogin.Controllers
{
    public class StudentController : Controller
    {
        private OurContext dbcontext;
        public StudentController(OurContext _dbcontext)
        {
            dbcontext = _dbcontext;
        }
        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Register()
        {
            return View();
        }
        [HttpPost]
        public IActionResult Register(RegisterModel register)
        {
            if (ModelState.IsValid)
            {
                Student obj = new Student();
                obj.FirstName = register.FirstName;
                obj.LastName = register.LastName;

                obj.Email = register.Email;
                obj.Phone = register.Mobile;
                obj.Password = register.ConfirmPassword;
                dbcontext.Add(obj);
                dbcontext.SaveChanges();
            }
            else
            {
                ModelState.AddModelError("", "Data is not correct");
            }
            return View();
        }

        [HttpGet]
        public IActionResult Login()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Login(LoginModel loginModel)
        {

            if (ModelState.IsValid)
            {
                var result = dbcontext.Students.Where(x => x.Email == loginModel.Email && x.Password == loginModel.Password).FirstOrDefault();
                if (result != null)
                {
                    HttpContext.Session.SetString("FirstName", result.FirstName);
                    HttpContext.Session.SetInt32("UserId", result.Id);
                    HttpContext.Session.SetString("EmailId", result.Email);
                    return RedirectToAction("Dashboard", "Student");
                }
                else
                {
                    ViewBag.InvalidUser = "Invalid username and password!";
                }
            }
            return View();
        }

        public IActionResult Dashboard()
        {
            return View();
        }


    }

}
